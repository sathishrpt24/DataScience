from flask import Flask, render_template, request
import
app = Flask(__name__)


@app.route('/')
def login_page():
    return render_template('loginpage.html')


@app.route('/home',methods=['GET'])
def home_page():
    return "This is home page"


@app.route('/registartionpage', methods=['GET','POST'])
def register_page():
    if request.method == "POST":
        name = request.form.get('NAME')
        gmail = request.form.get('GMAIL')
        phno = request.form.get('PHNO')
        t1 = DataRelated(name=name,gmail=gmail,phno=phno)
    return render_template('registrationpage.html')

import sqlalchemy as db

def createdb():
    engine = db.create_engine('mysql+pymysql://sathish:BTGS@2019@localhost:3306/northwind')
    connection = engine.connect()
    metadata= db.MetaData()
    return connection




if __name__ == '__main__':
    app.run(debug=True)

class DataRelated:
    def __init__(self,**kwargs):
        self.name = kwargs['name']
        self.gmail = kwargs['gmail']
        self.phno = kwargs['phno']